# JanoBox Android

Proyecto Android nativo en Kotlin para JanoBox. Incluye generador de números, calculadora, tonos, cambio de color y botón sorpresa.

## Compilar
El workflow de GitHub Actions (`Build JanoBox APK`) puede compilar el APK de depuración en la nube y guardarlo como artefacto. El APK resultante se llama `app-debug.apk`.

Este ZIP contiene el código fuente del proyecto, no un APK ya compilado.

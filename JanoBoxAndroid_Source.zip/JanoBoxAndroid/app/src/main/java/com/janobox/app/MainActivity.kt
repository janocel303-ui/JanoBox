package com.janobox.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.*
import android.media.AudioManager
import android.media.ToneGenerator
import kotlin.random.Random

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 17, 31)
    private val panel = Color.rgb(13, 27, 45)
    private val cyan = Color.rgb(67, 232, 255)
    private lateinit var root: LinearLayout
    private lateinit var numberMin: EditText
    private lateinit var numberMax: EditText
    private lateinit var numberResult: TextView
    private lateinit var calcA: EditText
    private lateinit var calcB: EditText
    private lateinit var calcOp: Spinner
    private lateinit var calcResult: TextView
    private lateinit var surpriseResult: TextView
    private val tones = listOf(
        "Tono" to ToneGenerator.TONE_DTMF_5,
        "Brillo" to ToneGenerator.TONE_PROP_ACK,
        "Bloop" to ToneGenerator.TONE_PROP_BEEP
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(root)
        setContentView(scroll)

        text("⚡ JanoBox", 30, cyan, true, 0, 2)
        text("Tu caja de cosas random · v1.0", 14, Color.LTGRAY, false, 0, 18)
        card("🎲 Número aleatorio", "Elegí un rango y dejá que decida el azar.") {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            numberMin = edit("Mínimo", "1")
            numberMax = edit("Máximo", "100")
            row.addView(numberMin, weightParams())
            row.addView(numberMax, weightParams())
            addView(row)
            button("¡Tirar número!") {
                val min = numberMin.text.toString().toLongOrNull()
                val max = numberMax.text.toString().toLongOrNull()
                if (min == null || max == null || max < min || max - min < 0) {
                    numberResult.text = "Revisá el rango: usá enteros y máximo ≥ mínimo."
                } else {
                    numberResult.text = "🎲 ${Random.nextLong(min, max + 1)}"
                }
            }
            numberResult = text("Tu número aparecerá acá.", 18, cyan, true, 0, 0)
        }
        card("🧮 Calculadora", "Cuentas rápidas.") {
            calcA = edit("Primer número", "")
            calcOp = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                    listOf("Sumar +", "Restar −", "Multiplicar ×", "Dividir ÷", "Potencia ^"))
            }
            addView(calcOp, matchParams())
            calcB = edit("Segundo número", "")
            button("Calcular") {
                val a = calcA.text.toString().toDoubleOrNull()
                val b = calcB.text.toString().toDoubleOrNull()
                if (a == null || b == null) calcResult.text = "Ingresá los dos números."
                else {
                    val r = when (calcOp.selectedItemPosition) {
                        0 -> a + b; 1 -> a - b; 2 -> a * b
                        3 -> if (b == 0.0) Double.NaN else a / b
                        else -> Math.pow(a, b)
                    }
                    calcResult.text = if (!r.isFinite()) "No se puede calcular ese resultado." else "Resultado: ${"%.8f".format(r).trimEnd('0').trimEnd('.')}"
                }
            }
            calcResult = text("Resultado: —", 16, cyan, true, 0, 0)
        }
        card("🔊 Laboratorio de sonidos", "Tonos sencillos generados por Android.") {
            tones.forEach { (name, tone) ->
                button("♪ $name") {
                    try { ToneGenerator(AudioManager.STREAM_MUSIC, 75).startTone(tone, 250) }
                    catch (_: Exception) { Toast.makeText(this@MainActivity, "No se pudo reproducir el tono", Toast.LENGTH_SHORT).show() }
                }
            }
        }
        card("🎨 Colorímetro", "Cambiá el color de fondo.") {
            val colors = listOf(
                Color.rgb(7,17,31), Color.rgb(16,44,59), Color.rgb(36,21,59),
                Color.rgb(53,32,24), Color.rgb(18,44,36), Color.rgb(23,44,80)
            )
            button("Cambiar color al azar") {
                val c = colors.random()
                root.setBackgroundColor(c)
                Toast.makeText(this@MainActivity, "Nuevo ambiente ⚡", Toast.LENGTH_SHORT).show()
            }
            button("Volver al azul original") { root.setBackgroundColor(bg) }
        }
        card("🎁 Botón sorpresa", "Apretalo y descubrí qué sale.") {
            surpriseResult = text("Esperando que aprietes el botón…", 17, cyan, true, 0, 0)
            button("ACTIVAR SORPRESA ⚡") {
                surpriseResult.text = listOf(
                    "¡POTENCIA MÁXIMA! ⚡", "MODO RANDOM ACTIVADO 🎲",
                    "Bloop espacial detectado 🛸", "✨ BRILLO INEXPLICABLE ✨",
                    "Nivel secreto desbloqueado 🏆", "QUEQUE PLAY SON G 🔹",
                    "Error 404: sorpresa no encontrada. Mentira 😎"
                ).random()
            }
        }
        text("Hecho para Jano · No requiere permisos especiales.", 12, Color.GRAY, false, 0, 10)
    }

    private fun card(title: String, subtitle: String, content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        root.addView(box, lp)
        val heading = text(title, 19, Color.WHITE, true, 0, 4)
        box.addView(heading)
        box.addView(text(subtitle, 13, Color.LTGRAY, false, 0, 8))
        box.content()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean, top: Int, bottom: Int): TextView {
        return TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(top), 0, dp(bottom))
            gravity = Gravity.CENTER_VERTICAL
        }
    }

    private fun edit(hintText: String, value: String): EditText {
        return EditText(this).apply {
            hint = hintText
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }.also { rootView ->
            // Kept intentionally simple; fields are styled by the active Android theme.
        }
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setTextColor(Color.rgb(4, 18, 29))
            setBackgroundColor(cyan)
            textSize = 14f
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(4) }
        root.addView(b, lp)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchParams() = LinearLayout.LayoutParams(-1, -2)
    private fun weightParams() = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) }
}
